
from flask import Flask, jsonify
from routes.admin_routes import admin_bp
from routes.users_routes import users_bp
from routes.guest_routes import guest_bp
from routes.auth_routes import auth_bp
from routes.quizzes_routes import quizzes_bp

app = Flask(__name__)
app.config["SECRET_KEY"] = "mysecret@1"
app.config["JSONIFY_PRETTYPRINT_REGULAR"] = True

# Register Blueprints
app.register_blueprint(auth_bp, url_prefix="/auth")
app.register_blueprint(users_bp, url_prefix="/users")
app.register_blueprint(admin_bp, url_prefix="/admin")
app.register_blueprint(guest_bp, url_prefix="/guest")
app.register_blueprint(quizzes_bp, url_prefix="/quizzes")

@app.route('/', methods=['GET'])
def home():
    return jsonify({"message": "Welcome to Quiz API - COM661 Project"})

if __name__ == "__main__":
    app.run(debug=True, port=5001)
