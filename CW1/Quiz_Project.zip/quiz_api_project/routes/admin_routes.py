# ----------------------------------
# Admin Routes – Quiz Management and Analytics
# ---------------------------

from flask import Blueprint, jsonify, request, make_response
from config.db_config import db
from utils.decorators import token_required

# Define bp for admin routes------------------
admin_bp = Blueprint('admin_bp', __name__)
quizzes = db.quizzes


# ------- Create new Quiz 
@admin_bp.route('/quizzes', methods=['POST'])
@token_required(role='admin')
def create_quiz():
    
    data = request.form if request.form else request.get_json()

    if not data or not data.get("title"):
        return make_response(jsonify({"error": "Quiz title is required"}), 400)

    try:
        new_quiz = {
            "quizId": f"QZ-{db.quizzes.count_documents({}) + 1:03}",
            "title": data.get("title"),
            "difficulty": data.get("difficulty", "Medium"),
            "creator": data.get("creator", {"name": "Admin"}),
            "questions": data.get("questions", []),
            "attempts": []
        }

        quizzes.insert_one(new_quiz)
        return make_response(jsonify({"message": "Quiz created successfully"}), 201)

    except Exception as e:
        return make_response(jsonify({"error": str(e)}), 500)


# - update existing quiz 
@admin_bp.route('/quizzes/<string:quizId>', methods=['PUT'])
@token_required(role='admin')
def update_quiz(quizId):
    

    data = request.form if request.form else request.get_json()
    update_fields = {k: v for k, v in data.items() if v}

    if not update_fields:
        return make_response(jsonify({"error": "No fields provided to update"}), 400)

    result = quizzes.update_one({"quizId": quizId}, {"$set": update_fields})

    if result.matched_count == 0:
        return make_response(jsonify({"error": "Quiz not found"}), 404)

    return make_response(jsonify({"message": "Quiz updated successfully"}), 200)


# ------ delete quiz -----------
@admin_bp.route('/quizzes/<string:quizId>', methods=['DELETE'])
@token_required(role='admin')
def delete_quiz(quizId):
    try:
        result = quizzes.delete_one({"quizId": quizId})
        if result.deleted_count == 0:
            return make_response(jsonify({"error": "Quiz not found"}), 404)
        return make_response(jsonify({"message": "Quiz deleted successfully"}), 200)
    except Exception as e:
        return make_response(jsonify({"error": str(e)}), 500)


#  view all quizzes ----------------
@admin_bp.route('/quizzes', methods=['GET'])
@token_required(role='admin')
def view_all_quizzes():
    
    try:
        all_quizzes = list(quizzes.find({}, {"_id": 0}))
        return make_response(jsonify(all_quizzes), 200)
    except Exception as e:
        return make_response(jsonify({"error": str(e)}), 500)


# - view quiz attempts ----------------
@admin_bp.route('/quizzes/<string:quizId>/attempts', methods=['GET'])
@token_required(role='admin')
def view_quiz_attempts(quizId):
    
    quiz = quizzes.find_one({"quizId": quizId}, {"_id": 0, "attempts": 1})

    if not quiz:
        return make_response(jsonify({"error": "Quiz not found"}), 404)

    return make_response(jsonify(quiz.get("attempts", [])), 200)


# Quiz Leaderboard ----------------
@admin_bp.route('/quizzes/<string:quizId>/leaderboard', methods=['GET'])
@token_required(role='admin')
def leaderboard(quizId):
    
    quiz = quizzes.find_one({"quizId": quizId})

    if not quiz:
        return make_response(jsonify({"error": "Quiz not found"}), 404)

    attempts = quiz.get("attempts", [])
    sorted_attempts = sorted(attempts, key=lambda x: x.get("score", 0), reverse=True)[:5]
    return make_response(jsonify(sorted_attempts), 200)


# quiz statistics ----------------
@admin_bp.route('/stats', methods=['GET'])
@token_required(role='admin')
def stats():
    try:
        pipeline = [
            {"$group": {"_id": "$difficulty", "count": {"$sum": 1}}},
            {"$sort": {"count": -1}}
        ]
        data = list(quizzes.aggregate(pipeline))
        return make_response(jsonify(data), 200)
    except Exception as e:
        return make_response(jsonify({"error": str(e)}), 500)
    
#    view single quiz ----------------

@admin_bp.route('/quizzes/<string:quizId>', methods=['GET'])
@token_required(role='admin')
def view_quiz(quizId):
    quiz = quizzes.find_one({"quizId": quizId}, {"_id": 0})
    if not quiz:
        return make_response(jsonify({"error": "Quiz not found"}), 404)
    return make_response(jsonify(quiz), 200)

