
from flask import Blueprint, request, jsonify, make_response
from config.db_config import db
from utils.decorators import token_required as jwt_required
import bcrypt, jwt, datetime

# Blueprint setup
users_bp = Blueprint('users_bp', __name__)
users = db.users
quizzes = db.quizzes  
blacklist = db.blacklist  

SECRET_KEY = "mysecret@1"


# --------------reg new user ----------------
@users_bp.route('/register', methods=['POST'])
def register_user():
    
    data = request.form if request.form else request.get_json()

    # Validate essential fields
    if not data.get('email') or not data.get('password'):
        return make_response(jsonify({"error": "Email and password are required"}), 400)

    # Prevent duplicate registration
    if users.find_one({"email": data.get('email')}):
        return make_response(jsonify({"error": "Email already registered"}), 409)

    hashed_pw = bcrypt.hashpw(data.get('password').encode('utf-8'), bcrypt.gensalt())

    new_user = {
        "name": data.get('name', 'Anonymous'),
        "email": data.get('email'),
        "password": hashed_pw,
        "role": data.get('role', 'user')
    }

    users.insert_one(new_user)
    return make_response(jsonify({"message": "User registered successfully"}), 201)


# ----------login user
@users_bp.route('/login', methods=['POST'])
def login_user():
    data = request.form if request.form else request.get_json()
    user = users.find_one({"email": data.get('email')})

    if not user or not bcrypt.checkpw(data.get('password').encode('utf-8'), user['password']):
        return make_response(jsonify({"error": "Invalid credentials"}), 401)

    token = jwt.encode({
        'user': user['email'],
        'role': user['role'],
        'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=2)
    }, SECRET_KEY, algorithm='HS256')

    return make_response(jsonify({'token': token}), 200)


# ----------view profile
@users_bp.route('/profile', methods=['GET'])
@jwt_required()
def user_profile():
    try:
        token = request.headers.get('x-access-token')
        data = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
        user = users.find_one({"email": data.get('user')}, {"_id": 0, "password": 0})

        if not user:
            return make_response(jsonify({"error": "User not found"}), 404)

        return make_response(jsonify(user), 200)

    except jwt.ExpiredSignatureError:
        return make_response(jsonify({"error": "Token expired"}), 401)
    except Exception:
        return make_response(jsonify({"error": "Invalid token"}), 401)


# ---------update user role
@users_bp.route('/update-role', methods=['PUT'])
@jwt_required(role='admin')
def update_user_role():
    data = request.form if request.form else request.get_json()
    email = data.get('email')
    new_role = data.get('role')

    if not email or not new_role:
        return make_response(jsonify({"error": "Email and new role are required"}), 400)

    result = users.update_one({"email": email}, {"$set": {"role": new_role}})

    if result.matched_count == 0:
        return make_response(jsonify({"error": "User not found"}), 404)

    return make_response(jsonify({"message": f"User role updated to {new_role}"}), 200)


# ---view user attempts
@users_bp.route('/<string:userId>/attempts', methods=['GET'])
@jwt_required(role='user')
def view_user_attempts(userId):
    
    try:
        user_attempts = []

        for quiz in quizzes.find({}, {"_id": 0, "quizId": 1, "title": 1, "attempts": 1}):
            for attempt in quiz.get("attempts", []):
                if attempt.get("userId") == userId:
                    user_attempts.append({
                        "quizId": quiz["quizId"],
                        "quizTitle": quiz["title"],
                        "score": attempt["score"],
                        "completed": attempt["completed"]
                    })

        if not user_attempts:
            return make_response(jsonify({"message": "No attempts found for this user"}), 200)

        return make_response(jsonify(user_attempts), 200)

    except Exception as e:
        return make_response(jsonify({"error": str(e)}), 500)


# ------------delete user account
@users_bp.route('/delete', methods=['DELETE'])
@jwt_required(role='user')
def delete_user_account():
    try:
        token = request.headers.get('x-access-token')
        data = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
        email = data.get('user')

        result = users.delete_one({"email": email})

        if result.deleted_count == 0:
            return make_response(jsonify({"error": "Account not found"}), 404)

        return make_response(jsonify({"message": "Account deleted successfully"}), 200)

    except jwt.ExpiredSignatureError:
        return make_response(jsonify({"error": "Token expired"}), 401)
    except Exception as e:
        return make_response(jsonify({"error": str(e)}), 500)


# ----logout user
@users_bp.route('/logout', methods=['POST'])
@jwt_required()
def logout_user():
    token = request.headers.get('x-access-token')

    # Check if already blacklisted
    if blacklist.find_one({"token": token}):
        return make_response(jsonify({"message": "Token already invalidated"}), 200)

    blacklist.insert_one({"token": token})
    return make_response(jsonify({"message": "User logged out successfully"}), 200)
