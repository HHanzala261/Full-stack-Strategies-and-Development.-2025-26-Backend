
from flask import request, jsonify, make_response
from config.db_config import db
from functools import wraps
import jwt

# Secret key 
SECRET_KEY = "mysecret@1"

blacklist = db.blacklist


# -----------token required decorator -----------
def token_required(role=None):

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            token = request.headers.get("x-access-token")

            # If no token provided
            if not token:
                return make_response(jsonify({"error": "Token missing"}), 401)

            # Check if the token exists in blacklist (revoked token)
            if blacklist.find_one({"token": token}):
                return make_response(jsonify({"error": "Token has been cancelled"}), 401)

            try:
                # Decode the JWT token using secret key
                data = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])

                # If role restriction is applied (e.g., admin-only route)
                if role and data.get("role") != role:
                    return make_response(jsonify({"error": "Access denied"}), 403)

            except jwt.ExpiredSignatureError:
                return make_response(jsonify({"error": "Token expired"}), 401)
            except jwt.InvalidTokenError:
                return make_response(jsonify({"error": "Invalid token"}), 401)
            except Exception as e:
                return make_response(jsonify({"error": f"Token validation failed: {str(e)}"}), 401)

            # Token valid → continue with the route
            return func(*args, **kwargs)

        return wrapper
    return decorator
