
from flask import Blueprint, jsonify, make_response
from config.db_config import db

guest_bp = Blueprint('guest_bp', __name__)
quizzes = db.quizzes

# -------public quizzes list ----
@guest_bp.route('/public', methods=['GET'])
def guest_quizzes():

    try:
        data = list(quizzes.find({}, {"_id": 0, "quizId": 1, "title": 1, "difficulty": 1}))
        return make_response(jsonify(data), 200)
    except Exception as e:
        return make_response(jsonify({"error": str(e)}), 500)


# -------quiz preview ----
@guest_bp.route('/<string:quizId>/preview', methods=['GET'])
def preview_quiz(quizId):
    
    try:
        quiz = quizzes.find_one({"quizId": quizId}, {"_id": 0, "title": 1, "difficulty": 1, "questions": 1})
        if not quiz:
            return make_response(jsonify({"error": "Quiz not found"}), 404)

        summary = {
            "quizId": quizId,
            "title": quiz["title"],
            "difficulty": quiz["difficulty"],
            "question_count": len(quiz.get("questions", []))
        }
        return make_response(jsonify(summary), 200)
    except Exception as e:
        return make_response(jsonify({"error": str(e)}), 500)
    
# ------------public leaderboard ----
@guest_bp.route('/quizzes/<string:quizId>/leaderboard', methods=['GET'])
def public_leaderboard(quizId):
    quiz = quizzes.find_one({"quizId": quizId})

    if not quiz:
        return make_response(jsonify({"error": "Quiz not found"}), 404)

    
    attempts = quiz.get("attempts", [])
    if not isinstance(attempts, list):
        return make_response(jsonify({"error": "Invalid attempts format"}), 500)

    sorted_attempts = sorted(attempts, key=lambda x: x.get("score", 0), reverse=True)[:5]
    return make_response(jsonify(sorted_attempts), 200)
