# Quiz Model - helper functions
from config.db_config import db
quizzes = db.quizzes

def find_all_quizzes():
    return list(quizzes.find())
