
# Auth Routes – Registration, Login and Logout

from flask import Blueprint, request, jsonify, make_response
from config.db_config import db
from utils.decorators import token_required
import bcrypt, jwt, datetime, base64

# Blueprint setup
auth_bp = Blueprint('auth_bp', __name__)
users = db.users
blacklist = db.blacklist
SECRET_KEY = "mysecret@1"


# -----register new user
@auth_bp.route('/register', methods=['POST'])
def register_user():
    data = request.form if request.form else request.get_json()

    if not data.get('email') or not data.get('password'):
        return make_response(jsonify({"error": "Email and password required"}), 400)
    if users.find_one({"email": data.get('email')}):
        return make_response(jsonify({"error": "Email already registered"}), 409)

    hashed_pw = bcrypt.hashpw(data.get('password').encode('utf-8'), bcrypt.gensalt())
    new_user = {
        "name": data.get('name', 'Anonymous'),
        "email": data.get('email'),
        "password": hashed_pw,
        "role": data.get('role', 'user')  
    }

    users.insert_one(new_user)
    return make_response(jsonify({"message": "User registered successfully"}), 201)


# --login existing user bauth + json
@auth_bp.route('/login', methods=['POST'])
def login_user():
    auth_header = request.headers.get('Authorization')
    data = None

    #   Basic Auth
    if auth_header and auth_header.startswith('Basic '):
        try:
            encoded = auth_header.split(" ")[1]
            decoded = base64.b64decode(encoded).decode("utf-8")
            email, password = decoded.split(":", 1)
            data = {"email": email, "password": password}
        except Exception as e:
            return make_response(jsonify({"error": f"Invalid Basic Auth format: {str(e)}"}), 400)

    #  JSON body 
    if not data:
        data = request.form if request.form else request.get_json()

    if not data or not data.get("email") or not data.get("password"):
        return make_response(jsonify({"error": "Email and password required"}), 400)

    #  Validate user
    user = users.find_one({"email": data.get("email")})
    if not user or not bcrypt.checkpw(data.get("password").encode("utf-8"), user["password"]):
        return make_response(jsonify({"error": "Invalid credentials"}), 401)

    #  generate JWT token
    token = jwt.encode({
        "user": user["email"],
        "role": user.get("role", "user"),
        "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=2)
    }, SECRET_KEY, algorithm="HS256")

   
    if isinstance(token, bytes):
        token = token.decode("utf-8")

    return make_response(jsonify({
        "token": token,
        "role": user.get("role", "user")
    }), 200)


# ----- logout user
@auth_bp.route('/logout', methods=['POST'])
@token_required()
def logout_user():
   
    token = request.headers.get('x-access-token')
    blacklist.insert_one({"token": token})
    return make_response(jsonify({"message": "Logged out successfully"}), 200)
