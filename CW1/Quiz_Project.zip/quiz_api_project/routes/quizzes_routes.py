

from flask import Blueprint, jsonify, request, make_response
from config.db_config import db
from utils.decorators import token_required
from bson import ObjectId
from collections import OrderedDict
import jwt

# Define blueprint for all quiz related routes
quizzes_bp = Blueprint('quizzes_bp', __name__)
quizzes = db.quizzes
SECRET_KEY = "mysecret@1"


# ------------get all quizzes (admin access) ----
@quizzes_bp.route('/', methods=['GET'])
def get_all_quizzes():
    
    data_to_return = []
    page_num = request.args.get('pn', default=1, type=int)
    page_size = request.args.get('ps', default=10, type=int)
    page_start = (page_num - 1) * page_size

    try:
        cursor = quizzes.find().skip(page_start).limit(page_size)

        for quiz in cursor:
            quiz["_id"] = str(quiz["_id"])
            ordered = OrderedDict()

            
            for key in ["quizId", "title", "difficulty", "creator", "questions", "attempts", "_id"]:
                if key in quiz:
                    ordered[key] = quiz[key]

            data_to_return.append(ordered)

        return make_response(jsonify(data_to_return), 200)

    except Exception as e:
        return make_response(jsonify({"error": str(e)}), 500)


# --guest routes -
@quizzes_bp.route('/public', methods=['GET'])
def guest_quizzes():
    
    try:
        data = list(quizzes.find({}, {"_id": 0, "quizId": 1, "title": 1, "difficulty": 1}))
        return make_response(jsonify(data), 200)
    except Exception as e:
        return make_response(jsonify({"error": str(e)}), 500)


@quizzes_bp.route('/<string:quizId>/preview', methods=['GET'])
def preview_quiz(quizId):
    
    try:
        quiz = quizzes.find_one(
            {"quizId": quizId},
            {"_id": 0, "title": 1, "difficulty": 1, "questions": 1}
        )

        if not quiz:
            return make_response(jsonify({"error": "Quiz not found"}), 404)

        summary = {
            "quizId": quizId,
            "title": quiz["title"],
            "difficulty": quiz["difficulty"],
            "question_count": len(quiz.get("questions", []))
        }

        return make_response(jsonify(summary), 200)

    except Exception as e:
        return make_response(jsonify({"error": str(e)}), 500)


# ---------get quiz details
@quizzes_bp.route('/<string:quizId>', methods=['GET'])
@token_required(role='user')
def get_quiz_details(quizId):
    
    try:
        quiz = quizzes.find_one({"quizId": quizId}, {"_id": 0})
        if not quiz:
            return make_response(jsonify({"error": "Quiz not found"}), 404)

        
        if "questions" in quiz:
            if isinstance(quiz["questions"], list):
                for q in quiz["questions"]:
                    q.pop("correct_answer", None)
            elif isinstance(quiz["questions"], dict):
                quiz["questions"].pop("correct_answer", None)

        return make_response(jsonify(quiz), 200)
    except Exception as e:
        return make_response(jsonify({"error": str(e)}), 500)


# ---------submit quiz attempt ----
@quizzes_bp.route('/<string:quizId>/attempts', methods=['POST'])
@token_required(role='user')
def submit_quiz_attempt(quizId):
    
    data = request.get_json()

    user_email = data.get('email')
    answers = data.get('answers', [])

    # Fetch quiz data
    quiz = quizzes.find_one({"quizId": quizId})
    if not quiz:
        return make_response(jsonify({"error": "Quiz not found"}), 404)

    questions = quiz.get("questions", [])
    score = 0

    # Calculate score
    if isinstance(questions, list):
        for idx, question in enumerate(questions):
            if idx < len(answers) and answers[idx] == question.get("correct_answer"):
                score += question.get("marks", 0)
    elif isinstance(questions, dict):
        # Single question quiz
        if answers and answers[0] == questions.get("correct_answer"):
            score = questions.get("marks", 0)

    attempt_record = {
        "userId": data.get('userId'),
        "name": data.get('name'),
        "email": user_email,
        "score": score,
        "completed": True
    }

    
    if not isinstance(quiz.get("attempts"), list):
        quizzes.update_one({"quizId": quizId}, {"$set": {"attempts": []}})

   
    quizzes.update_one(
        {"quizId": quizId},
        {"$push": {"attempts": attempt_record}}
    )

    return make_response(jsonify({
        "message": "Attempt submitted successfully",
        "score": score
    }), 201)


# -------public leaderboard ----
@quizzes_bp.route('/<string:quizId>/leaderboard', methods=['GET'])
def public_leaderboard(quizId):
    try:
        quiz = quizzes.find_one({"quizId": quizId})
        if not quiz:
            return make_response(jsonify({"error": "Quiz not found"}), 404)

        attempts = quiz.get("attempts", [])
        sorted_attempts = sorted(attempts, key=lambda x: x.get("score", 0), reverse=True)[:5]

        return make_response(jsonify(sorted_attempts), 200)
    except Exception as e:
        return make_response(jsonify({"error": str(e)}), 500)
